import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-place-booking',
  templateUrl: './place-booking.page.html',
  styleUrls: ['./place-booking.page.scss'],
})
export class PlaceBookingPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
