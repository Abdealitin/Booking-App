export const firebaseConfig = {
  apiKey: "AIzaSyB9yW0eaYWk5s8-hi_-1jhnyNNy8gTh1Oo",
  authDomain: "booking-app-3cf5e.firebaseapp.com",
  databaseURL: "https://booking-app-3cf5e-default-rtdb.firebaseio.com",
  projectId: "booking-app-3cf5e",
  storageBucket: "booking-app-3cf5e.appspot.com",
  messagingSenderId: "1019791473600",
  appId: "1:1019791473600:web:e2d732c7810e7510322625",
  measurementId: "G-5KRE51SDSZ"
};
