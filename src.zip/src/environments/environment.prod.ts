export const environment = {
  production: true,
  googleMapsAPIKey : 'AIzaSyB9yW0eaYWk5s8-hi_-1jhnyNNy8gTh1Oo',
  firebaseApiKey: 'AIzaSyB9yW0eaYWk5s8-hi_-1jhnyNNy8gTh1Oo'
};
